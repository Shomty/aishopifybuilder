
# Change Log

## [5.0.0] - 2024-03-23
- New release

## [4.0.0] - 2022-12-26
- New release

## [3.1.0] - 2021-06-02
- Small fix with fonts missing semicolumn #57
- Recommended products JS issue in the homepage #58
- Megamenu in offcanvas menu is missing #60
- Search page is missing styles #62
- Delete empty file "section/offcanvas-menu.liquid" #59
- Update package.json required dependencies #64
- Issue on the collection filters, when 2 values are the same #65
- Options selector script doesn't work with 3 product options #66
- Newsletter section has wrong closing div tag #67
- Fonts should be loaded below the bootstrap.css file #68

## [3.0.0] - 2021-05-16